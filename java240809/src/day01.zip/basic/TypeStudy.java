package day01.basic;

public class TypeStudy {
	public static void main(String[] args) {
//		ctrl + shift + F => 포맷정리
		
//		자료형
//		숫자형
//			정수형
//			int <-default : +-21억
//			short, long
//			실수형
//			double <- default
//			float
//		문자형
//			문자 char
//			하나의 문자를 나타는 자료형으로,
//			작은따옴표(')로 문자 하나를 감싼 형태로 표현된다.
//			문자열 String
//			여러 개의 문자를 나타내는 자료형으로,
//			큰 따옴표(")로 문자들을 감싼 형태로 표현된다.
//		논리형
//			참/거짓
//			boolean
//			true, false

		
		
		
		
		
		
		
	}
}
